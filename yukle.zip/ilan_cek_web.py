#!/usr/bin/env python3
"""KamuRadar toplayici: birden cok kaynaktan ilan toplar, ilanlar.json'a yazar.

Her kaynak ayri calisir; biri hata verirse digerleri devam eder. Sonuc durumu
(tamam / hata / kontrol-edilmeli) ilanlar.json icindeki "kaynaklar" alanina yazilir,
sitede kaynak rozetleri olarak gorunur.

Kaynak listesi:
  1) ilan.gov.tr         (Basin Ilan Kurumu, ic servisi)
  2) Kariyer Kapisi      (resmi RSS)
  3) ek_kaynaklar.json   (RSS ya da HTML sayfa: istedigin kadar kaynak eklenebilir)
  4) manuel_ilanlar.json (elle yazdigin ilanlar)

Bilgisayarinda:  python ilan_cek_web.py
"""
import hashlib
import json
import os
import re
import sys
import time
import xml.etree.ElementTree as ET
from datetime import date, datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from html.parser import HTMLParser
from urllib.parse import urljoin

if sys.platform == "win32":   # Windows'ta sistemin sertifika deposunu kullan (SSL hatasini onler)
    try:
        import truststore
        truststore.inject_into_ssl()
    except ImportError:
        pass

import requests

import ayristir as ic

KLASOR = os.path.dirname(os.path.abspath(__file__))
CIKTI = os.path.join(KLASOR, "ilanlar.json")
EK_KAYNAK_DOSYASI = os.path.join(KLASOR, "ek_kaynaklar.json")
MANUEL_DOSYASI = os.path.join(KLASOR, "manuel_ilanlar.json")
ESKI_GUN = 30            # son basvurusu bu kadar gun once gecenleri sil
TARIHSIZ_GUN = 60        # son tarihi olmayanlari, ilk gorulmesinden bu kadar gun sonra sil
ACIKLAMA_SINIR = 2500
DETAY_LIMIT = 80         # her kaynakta bir calismada en fazla bu kadar ilan sayfasi acilir
UA = {"user-agent": "Mozilla/5.0 (compatible; KamuRadar/1.0; kisisel kullanim)"}


def iso(d):
    return d.isoformat() if d else None


def satir_id(link):
    return int(hashlib.md5(link.encode("utf-8")).hexdigest()[:8], 16)


def temel_satir(link, **alanlar):
    row = {
        "id": satir_id(link), "institution": "", "title": "", "city": "", "department": "Herhangi",
        "education_level": "", "kpss_type": "", "min_kpss": None, "quota": None,
        "deadline": None, "application_start": None, "link": link, "source_url": link,
        "source_name": "", "employment_type": "Diğer", "description": "",
        "checked_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    row.update(alanlar)
    return row


def detay_oku(session, url):
    """Ilan sayfasini acip duz metnini dondurur (hata olursa bos)."""
    try:
        r = session.get(url, headers=UA, timeout=25)
        if r.status_code != 200:
            return ""
        return ic.duz_metin(r.content.decode("utf-8", "replace"))[:ACIKLAMA_SINIR]
    except requests.RequestException:
        return ""


def detaydan_doldur(row, metin):
    """Detay metninden bos kalan alanlari doldurur."""
    if not metin:
        return
    tum = f"{row.get('title', '')} {metin}"
    row["description"] = (row.get("description", "") + " | " + metin)[:ACIKLAMA_SINIR]
    if not row.get("min_kpss"):
        row["min_kpss"] = ic.parse_min_kpss(tum)
    if row.get("kpss_type") in ("", None):
        row["kpss_type"] = ic.parse_kpss_type(tum)
    if not row.get("education_level"):
        row["education_level"] = ic.parse_education(tum)
    if not row.get("deadline"):
        b, e = ic.parse_application_dates(metin)
        row["deadline"] = row["deadline"] or iso(e)
        row["application_start"] = row.get("application_start") or iso(b)
    if not row.get("city"):
        row["city"] = ic.bul_sehir(f"{row.get('institution', '')} {row.get('title', '')}", metin)
    if row.get("employment_type") in ("", None, "Diğer"):
        row["employment_type"] = ic.guess_employment(tum)


# ---------------------------------------------------------------- 1) ilan.gov.tr
def ek_sertifika_paketi(host):
    """Sitenin eksik 'ara sertifika'sini kendi sertifikasindaki adresten (AIA) indirip
    certifi listesiyle birlestirir. Linux sunucularda 'SSLCertVerificationError' hatasini cozer."""
    import socket
    import ssl
    import tempfile

    import certifi
    from cryptography import x509
    from cryptography.hazmat.primitives import serialization

    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    with socket.create_connection((host, 443), timeout=20) as s, ctx.wrap_socket(s, server_hostname=host) as t:
        der = t.getpeercert(binary_form=True)
    cert = x509.load_der_x509_certificate(der)
    pemler = []
    for _ in range(4):
        try:
            aia = cert.extensions.get_extension_for_class(x509.AuthorityInformationAccess).value
        except x509.ExtensionNotFound:
            break
        urller = [d.access_location.value for d in aia
                  if d.access_method == x509.oid.AuthorityInformationAccessOID.CA_ISSUERS]
        if not urller:
            break
        veri = requests.get(urller[0], timeout=20).content
        try:
            cert = x509.load_der_x509_certificate(veri)
        except ValueError:
            cert = x509.load_pem_x509_certificate(veri)
        pemler.append(cert.public_bytes(serialization.Encoding.PEM))
    yol = os.path.join(tempfile.gettempdir(), "kamuradar_ca.pem")
    with open(certifi.where(), "rb") as f:
        temel = f.read()
    with open(yol, "wb") as f:
        f.write(temel + b"\n" + b"\n".join(pemler))
    print(f"[ilan.gov.tr] eksik ara sertifika tamamlandi ({len(pemler)} sertifika eklendi)")
    return yol


def ilan_gov_tr(session, mevcut, **_):
    try:
        session.post(ic.SEARCH_URL, json={"keys": {"ats": [ic.AD_TYPE_PERSONEL]}, "skipCount": 0, "maxResultCount": 1},
                     headers=ic.HEADERS, timeout=30)
    except requests.exceptions.SSLError:
        print("[ilan.gov.tr] SSL sertifika hatasi, eksik ara sertifika araniyor...")
        session.verify = ek_sertifika_paketi("www.ilan.gov.tr")
    eklenen = 0
    for page in range(ic.MAX_PAGES):
        keys = {"ats": [ic.AD_TYPE_PERSONEL]}
        if page > 0:
            keys["currentPage"] = [page + 1]
        payload = {"keys": keys, "skipCount": page * ic.PAGE_SIZE, "maxResultCount": ic.PAGE_SIZE}
        r = session.post(ic.SEARCH_URL, json=payload, headers=ic.HEADERS, timeout=30)
        r.raise_for_status()
        result = r.json().get("result") or {}
        ads = result.get("ads") or []
        if page == 0:
            print(f"[ilan.gov.tr] sitedeki toplam ilan: {result.get('numFound', '?')}")
        if not ads:
            break
        toplam = int(result.get("numFound") or 0)
        for ad in ads:
            if ad.get("isArchived") or not ad.get("urlStr"):
                continue
            if not getattr(ilan_gov_tr, "_anahtar_yazildi", False):
                ilan_gov_tr._anahtar_yazildi = True
                print("[ilan.gov.tr] ilan alanlari:", sorted(ad.keys()))
            logo = ""
            for _k, _v in ad.items():
                if "logo" in str(_k).lower() and isinstance(_v, str) and _v.strip():
                    logo = _v.strip(); break
            if logo.startswith("/"):
                logo = "https://www.ilan.gov.tr" + logo
            akademik = any(w in ic.norm(f"{ad.get('title', '')} {ad.get('advertiserName', '')}") for w in ic.SKIP_WORDS)
            link = ic.build_link(ad["urlStr"])
            if link in mevcut:
                continue
            time.sleep(ic.DELAY)
            try:
                body, _d = ic.fetch_detail(session, ad.get("id"))
            except (requests.RequestException, ValueError) as e:
                print(f"Detay alinamadi ({ad.get('id')}): {e}")
                body = ""
            metin = f"{ad.get('title', '')} {body}"
            bas, bit = ic.parse_application_dates(metin)
            mevcut[link] = temel_satir(
                link, institution=ad.get("advertiserName") or "", title=ad.get("title") or "",
                city=ad.get("addressCityName") or "", education_level=ic.parse_education(metin),
                kpss_type=ic.parse_kpss_type(metin), min_kpss=ic.parse_min_kpss(metin),
                deadline=iso(bit), application_start=iso(bas), puanlar=ic.parse_puan_tablosu(metin),
                source_name="ilan.gov.tr", employment_type=ic.guess_employment(metin),
                description=body[:ACIKLAMA_SINIR], akademik=akademik, logo=logo)
            eklenen += 1
            print(f"+ {ad.get('advertiserName')} - {ad.get('title')}")
        time.sleep(ic.DELAY)
        if toplam and (page + 1) * ic.PAGE_SIZE >= toplam:
            break
    return eklenen


# ---------------------------------------------------------------- 2) Kariyer Kapisi
def kariyer_kapisi(session, mevcut, **_):
    r = session.get(ic.KK_RSS_URL, headers={**UA, "accept": "application/rss+xml, application/xml"}, timeout=30)
    r.raise_for_status()
    root = ET.fromstring(r.content)
    eklenen = 0
    detay_hak = 0   # Kariyer Kapisi ilan sayfalari JavaScript ile yukleniyor, okunamaz
    for item in root.iter("item"):
        link = (item.findtext("link") or "").strip()
        baslik = (item.findtext("title") or "").strip()
        kategori = (item.findtext("category") or "").strip()
        if not link or not baslik or any(w in ic.norm(kategori) for w in ic.KK_ATLA_KATEGORI):
            continue
        try:
            tarih = parsedate_to_datetime(item.findtext("pubDate") or "").date()
        except (TypeError, ValueError):
            tarih = None
        if link in mevcut:
            if tarih and not mevcut[link].get("application_start"):
                mevcut[link]["application_start"] = iso(tarih)
            continue
        kurum, ilan_basligi = ic.kk_ayir(baslik)
        metin = f"{baslik} {kategori}"
        mevcut[link] = temel_satir(
            link, institution=kurum or ilan_basligi, title=ilan_basligi, application_start=iso(tarih),
            source_name="Kariyer Kapısı", employment_type=ic.kk_calisma_turu(kategori),
            description=f"{baslik} ({kategori})", education_level=ic.parse_education(metin),
            akademik=any(w in ic.norm(metin) for w in ic.SKIP_WORDS))
        if detay_hak > 0:
            detay_hak -= 1
            time.sleep(0.4)
            detaydan_doldur(mevcut[link], detay_oku(session, link))
        mevcut[link]["city"] = mevcut[link].get("city") or ic.bul_sehir(f"{kurum} {ilan_basligi}")
        eklenen += 1
        print(f"+ {kurum or ilan_basligi} - {ilan_basligi}")
    return eklenen


# ---------------------------------------------------------------- 3) ek kaynaklar
class _LinkOkuyucu(HTMLParser):
    def __init__(self):
        super().__init__()
        self.linkler, self._href, self._metin = [], None, []

    def handle_starttag(self, tag, attrs):
        if tag == "a":
            self._href = dict(attrs).get("href")
            self._metin = []

    def handle_data(self, data):
        if self._href is not None:
            self._metin.append(data)

    def handle_endtag(self, tag):
        if tag == "a" and self._href is not None:
            self.linkler.append((self._href, re.sub(r"\s+", " ", "".join(self._metin)).strip()))
            self._href = None


def ek_kaynak(session, mevcut, kaynak=None, **_):
    """ek_kaynaklar.json'daki bir kaynagi okur. tur: 'rss' ya da 'html'."""
    ad, url = kaynak["ad"], kaynak["url"]
    anahtar = [ic.norm(k) for k in kaynak.get("anahtar", [])]
    kontrol = bool(kaynak.get("deneme", False))
    r = session.get(url, headers=UA, timeout=30)
    r.raise_for_status()
    bulunan = []   # (link, baslik, tarih)
    if kaynak.get("tur") == "rss":
        root = ET.fromstring(r.content)
        for item in root.iter("item"):
            try:
                t = parsedate_to_datetime(item.findtext("pubDate") or "").date()
            except (TypeError, ValueError):
                t = None
            bulunan.append(((item.findtext("link") or "").strip(), (item.findtext("title") or "").strip(), t))
    else:
        p = _LinkOkuyucu()
        p.feed(r.content.decode("utf-8", "replace"))
        for href, metin in p.linkler:
            if href and not href.startswith(("#", "javascript:", "mailto:")):
                bulunan.append((urljoin(url, href), metin, None))
    link_liste = bool(kaynak.get("link_liste", False))   # detay adresi gecici ise listeye yonlendir
    if link_liste:   # eski (gecersiz detay adresli) kayitlari temizle
        for l in [l for l, r_ in mevcut.items() if r_.get("source_name") == ad and "#" not in l]:
            del mevcut[l]
    eklenen = 0
    detay_hak = DETAY_LIMIT if kaynak.get("detay") else 0
    for gercek, baslik, tarih in bulunan:
        if not gercek or len(baslik) < 25:
            continue
        if anahtar and not any(k in ic.norm(baslik) for k in anahtar):
            continue
        baslik = ic.baslik_duzelt(baslik)
        link = (url + "#" + hashlib.md5(baslik.encode("utf-8")).hexdigest()[:10]) if link_liste else gercek
        if link in mevcut:
            continue
        bas, bit = ic.parse_tarih_araligi(baslik)
        if not bit:
            bas, bit = ic.parse_application_dates(baslik)
        kurum, kont = ic.baslik_ayir(baslik)
        mevcut[link] = temel_satir(
            link, institution=kurum or kaynak.get("kurum") or ad, title=baslik, source_name=ad, source_url=url,
            application_start=iso(bas or tarih), deadline=iso(bit), quota=kont,
            education_level=ic.parse_education(baslik), kpss_type=ic.parse_kpss_type(baslik),
            min_kpss=ic.parse_min_kpss(baslik), employment_type=ic.guess_employment(baslik),
            description=baslik, kontrol_gerekli=kontrol,
            akademik=any(w in ic.norm(baslik) for w in ic.SKIP_WORDS))
        if detay_hak > 0:
            detay_hak -= 1
            time.sleep(0.4)
            detaydan_doldur(mevcut[link], detay_oku(session, gercek))
        mevcut[link]["city"] = mevcut[link].get("city") or ic.bul_sehir(mevcut[link]["institution"] + " " + baslik)
        eklenen += 1
        print(f"+ [{ad}] {baslik}")
    return eklenen


# ---------------------------------------------------------------- 4) elle girilenler
def manuel_ilanlar(mevcut):
    if not os.path.exists(MANUEL_DOSYASI):
        return 0
    with open(MANUEL_DOSYASI, encoding="utf-8") as f:
        liste = json.load(f)
    n = 0
    for m in liste:
        if not m.get("link") or not m.get("title"):
            continue
        alanlar = {k: v for k, v in m.items() if k != "link"}
        alanlar.setdefault("source_name", "Manuel ekleme")
        satir = temel_satir(m["link"], **alanlar)
        eski = mevcut.get(m["link"])
        if eski:
            satir["checked_at"] = eski.get("checked_at", satir["checked_at"])
        mevcut[m["link"]] = satir
        n += 1
    return n


# ---------------------------------------------------------------- ortak
def puanlari_yenile(mevcut):
    n = 0
    for row in mevcut.values():
        metin = f"{row.get('title', '')} {row.get('description', '')}"
        if not row.get("min_kpss"):
            p = ic.parse_min_kpss(metin)
            if p is not None:
                row["min_kpss"] = p
                n += 1
        if not row.get("deadline"):
            _, bit = ic.parse_application_dates(metin)
            if bit:
                row["deadline"] = iso(bit)
        if not row.get("education_level"):
            row["education_level"] = ic.parse_education(metin)
        if "puanlar" not in row:
            pt = ic.parse_puan_tablosu(metin)
            row["puanlar"] = pt
            if pt:
                row["min_kpss"] = min(pt.values())
                row["egitimler"] = sorted({ic.tur_egitim(t) for t in pt})
                n += 1
        # egitim: once ilan metninde ACIKCA yazan; yoksa KPSS turunden tahmin (isaretli)
        e = ic.parse_egitimler(metin)
        if e:
            row["egitimler"] = e
            row["egitim_tahmin"] = False
        elif row.get("puanlar"):
            row["egitimler"] = sorted({ic.tur_egitim(t) for t in row["puanlar"]})
            row["egitim_tahmin"] = True
        if not row.get("min_kpss"):
            p = ic.parse_puan_ek(metin)
            if p is not None:
                row["min_kpss"] = p
                n += 1
        nn = ic.norm(row.get("title", ""))
        ilk = ic.norm((row.get("description") or "")[:700])
        if re.search(r"\bIPTAL\b|DUZELTME ILANI", nn) or "IPTAL ILANI" in ilk[:250] or "DUZELTME ILANI" in ilk[:250]:
            row["iptal"] = True
        if any(w in ilk or w in nn for w in ("OGRETIM ELEMANI", "OGRETIM UYESI", "ARASTIRMA GOREVLISI", "OGRETIM GOREVLISI")):
            row["akademik"] = True
        d = row.get("description") or ""
        if "sayfa bulunamad" in d.lower() or "Ã" in d or "Ä" in d:   # bozuk/404 sayfa metni
            row["description"] = row.get("title", "")
        if not row.get("city"):
            row["city"] = ic.bul_sehir(f"{row.get('institution', '')} {row.get('title', '')}", row.get("description", ""))
    return n


def tekillestir(ilanlar):
    """Ayni kurumun ayni basligi iki kaynaktan geldiyse tek kayit birakir (dogrudan linki olani ve ilk gorulenini)."""
    import re as _re
    def anahtar(r):
        t = f"{r.get('institution', '')}|{r.get('title', '')}".lower()
        return _re.sub(r"[^0-9a-zçğıöşü]+", "", t)[:140]
    gruplar = {}
    for r in ilanlar:
        gruplar.setdefault(anahtar(r), []).append(r)
    sonuc = []
    for g in gruplar.values():
        if len(g) == 1:
            sonuc.append(g[0]); continue
        g.sort(key=lambda r: ("#" in str(r.get("link", "")), str(r.get("checked_at") or "")))
        ana = dict(g[0])
        ana["checked_at"] = min([str(x.get("checked_at") or "") for x in g if x.get("checked_at")] or [""]) or ana.get("checked_at")
        ana["diger_kaynaklar"] = sorted({x.get("source_name", "") for x in g[1:] if x.get("source_name")})
        sonuc.append(ana)
    return sonuc


def main():
    mevcut, eski_kaynaklar, eski_guncelleme = {}, {}, None
    if os.path.exists(CIKTI):
        with open(CIKTI, encoding="utf-8") as f:
            eski = json.load(f)
        eski_kaynaklar = eski.get("kaynaklar") or {}
        eski_guncelleme = eski.get("guncelleme")
        for row in eski.get("ilanlar") or []:
            mevcut[row["link"]] = row

    def imza(ilanlar, kaynaklar):
        k = {ad: {x: y for x, y in d.items() if x != "son_basari"} for ad, d in kaynaklar.items()}
        return json.dumps([sorted(ilanlar, key=lambda r: r["id"]), k], ensure_ascii=False, sort_keys=True)

    onceki = imza(list(mevcut.values()), eski_kaynaklar)

    isler = [("ilan.gov.tr", ilan_gov_tr, {}), ("Kariyer Kapısı", kariyer_kapisi, {})]
    if os.path.exists(EK_KAYNAK_DOSYASI):
        with open(EK_KAYNAK_DOSYASI, encoding="utf-8") as f:
            for k in json.load(f):
                if k.get("aktif", True):
                    isler.append((k["ad"], ek_kaynak, {"kaynak": k}))

    session = requests.Session()
    durumlar = {}
    for ad, fn, ekstra in isler:
        print(f"--- {ad}")
        try:
            eklenen = fn(session, mevcut, **ekstra)
            durumlar[ad] = {"durum": "tamam", "yeni": eklenen,
                            "son_basari": datetime.now(timezone.utc).isoformat(timespec="seconds")}
            if ekstra.get("kaynak", {}).get("deneme"):
                durumlar[ad]["not"] = "deneme kaynağı: ilanlar resmî sayfadan kontrol edilmeli"
            print(f"{ad}: tamam, {eklenen} yeni")
        except Exception as e:  # bir kaynak cokse digerleri calissin
            mesaj = f"{type(e).__name__}: {e}"[:160]
            print(f"! {ad} hata verdi: {mesaj}")
            onceki_d = eski_kaynaklar.get(ad) or {}
            if onceki_d.get("durum") in ("tamam", "eski"):   # daha once okunduysa eski ilanlar duruyor
                durumlar[ad] = {"durum": "eski", "mesaj": mesaj, "son_basari": onceki_d.get("son_basari") or eski_guncelleme}
            else:
                durumlar[ad] = {"durum": "hata", "mesaj": mesaj}

    pasif = {k["ad"] for k in (json.load(open(EK_KAYNAK_DOSYASI, encoding="utf-8")) if os.path.exists(EK_KAYNAK_DOSYASI) else [])
             if not k.get("aktif", True)}
    for l in [l for l, r_ in mevcut.items() if r_.get("source_name") in pasif]:
        del mevcut[l]
    print(f"Manuel ilan: {manuel_ilanlar(mevcut)}")
    print(f"Puani/tarihi yeni bulunan: {puanlari_yenile(mevcut)}")

    bugun = date.today()
    for link, r in list(mevcut.items()):
        if r.get("deadline"):
            if r["deadline"] < (bugun - timedelta(days=ESKI_GUN)).isoformat():
                del mevcut[link]
        else:
            ilk = (r.get("application_start") or r.get("checked_at") or "")[:10]
            if ilk and ilk < (bugun - timedelta(days=TARIHSIZ_GUN)).isoformat():
                del mevcut[link]

    sayilar = {}
    for r in mevcut.values():
        sayilar[r.get("source_name", "?")] = sayilar.get(r.get("source_name", "?"), 0) + 1
    for ad, d in durumlar.items():
        d["sayi"] = sayilar.get(ad, 0)

    ilanlar = sorted(tekillestir(list(mevcut.values())), key=lambda r: r["id"])
    # ilanlardan yeni bolum adlarini otomatik ogren (kalici; ilanlar silinse de listede kalir)
    try:
        onceki_bolum = {}
        if os.path.exists(CIKTI):
            with open(CIKTI, encoding="utf-8") as f:
                onceki_bolum = json.load(f).get("bolumler", {}) or {}
        bolumler = ic.bolum_ogren(ilanlar, onceki_bolum)
    except Exception as e:
        print("bolum ogrenme atlandi:", e)
        bolumler = {}
    simdi = datetime.now(timezone.utc).isoformat(timespec="seconds")
    degisti = imza(ilanlar, durumlar) != onceki
    # "guncelleme": ilanlar son ne zaman degisti; "son_kontrol": toplayici en son ne zaman calisti
    with open(CIKTI, "w", encoding="utf-8") as f:
        json.dump({"guncelleme": simdi if degisti else (eski_guncelleme or simdi), "son_kontrol": simdi,
                   "kaynaklar": durumlar, "bolumler": bolumler, "ilanlar": ilanlar}, f, ensure_ascii=False, indent=1)
    print(f"ilanlar.json yazildi: {len(ilanlar)} ilan ({'degisiklik var' if degisti else 'degisiklik yok'})")
    if all(d["durum"] in ("hata", "eski") for d in durumlar.values()):
        sys.exit(1)


if __name__ == "__main__":
    main()
